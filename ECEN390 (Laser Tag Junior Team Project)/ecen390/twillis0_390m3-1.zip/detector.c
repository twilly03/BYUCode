#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "detector.h"
#include "buffer.h"
#include "filter.h"
#include "mio.h"
#include "switches.h"
#include "interrupts.h"
#include "lockoutTimer.h"
#include "hitLedTimer.h"

#define DETECTOR_HIT_ARRAY_SIZE 10
#define FREQ_LIST_SIZE 10
#define MEDIAN_INDEX_SORTED_POWERS 5

volatile static bool detector_hitDetectedFlag;
volatile static bool ignoreAllHits;
volatile static bool ignoredFrequencies[FREQ_LIST_SIZE];
volatile static double scaledAdcValue;
volatile static double threshold;
volatile static double maxValue;
volatile static uint16_t frequencyOfLastHit;
volatile static uint16_t newInputCount;
volatile static uint32_t detectorInvocationCount;
volatile static uint32_t elementCount;
volatile static uint32_t fudgeFactorIndex;
volatile static detector_hitCount_t detector_hitArray[DETECTOR_HIT_ARRAY_SIZE];
volatile static buffer_data_t rawAdcValue;
static double computedPowers[DETECTOR_HIT_ARRAY_SIZE];

//sub function used to call our hit detection algorithm
void hit_detect();

// Initialize the detector module.
// By default, all frequencies are considered for hits.
// Assumes the filter module is initialized previously.
void detector_init(void) {double
    newInputCount = 0;
    detectorInvocationCount = 0;
    elementCount = 0;
    fudgeFactorIndex = 0;
    rawAdcValue = 0;

    //set all frequencies available to be hit
    for(uint8_t i = 0; i < FREQ_LIST_SIZE; i++) {
        ignoredFrequencies[i] = false;
    }

    //set the hit counts to zero
    for(uint8_t i = 0; i < DETECTOR_HIT_ARRAY_SIZE; i++) {
        detector_hitArray[i] = 0;
    }

}

// freqArray is indexed by frequency number. If an element is set to true,
// the frequency will be ignored. Multiple frequencies can be ignored.
// Your shot frequency (based on the switches) is a good choice to ignore.
void detector_setIgnoredFrequencies(bool freqArray[]) {
    
    uint32_t switchValueRead = switches_read(); 

    //copy the array over into the global array for access throughout the program.
    for(uint8_t i = 0; i < FREQ_LIST_SIZE; i++) {
        ignoredFrequencies[i] = freqArray[i];
    }
    
    //turn off the player's selected frequency.
    if(switchValueRead < FREQ_LIST_SIZE) {
        ignoredFrequencies[switchValueRead] = true;
    }

}

// Runs the entire detector: decimating FIR-filter, IIR-filters,
// power-computation, hit-detection. If interruptsCurrentlyEnabled = true,
// interrupts are running. If interruptsCurrentlyEnabled = false you can pop
// values from the ADC buffer without disabling interrupts. If
// interruptsCurrentlyEnabled = true, do the following:
// 1. disable interrupts.
// 2. pop the value from the ADC buffer.
// 3. re-enable interrupts.
// Ignore hits on frequencies specified with detector_setIgnoredFrequencies().
// Assumption: draining the ADC buffer occurs faster than it can fill.
void detector(bool interruptsCurrentlyEnabled) {
    elementCount = buffer_elements();
    newInputCount = 0;

    //loop through the elements in the buffer and perform desired operations to calculate if a hit was detected.
    for(uint16_t i = 0; i < elementCount; i++){
        //If interrupts are enabled (check to see if the interruptsEnabled argument == true), briefly disable interrupts by invoking interrupts_disableArmInts()
        if(interruptsCurrentlyEnabled){
            interrupts_disableArmInts();
            rawAdcValue = buffer_pop();
            interrupts_enableArmInts();
        }
        else{
            rawAdcValue = buffer_pop();
        }
        
        //Scale the integer value contained in rawAdcValue to a double that is between -1.0 and 1.0. Store this value into a variable named scaledAdcValue
        double scaledAdcValue = (double)rawAdcValue / 4095.0 * 2.0 - 1.0; //The ADC generates a 12-bit output that ranges from 0 to 4095. 0 would map to -1.0. 4095 maps to 1.0
        filter_addNewInput(scaledAdcValue);
        newInputCount++;
        //If filter_addNewInput() has been called 10 times since the last invocation of the FIR and IIR filters, run the FIR filter, IIR filter and power computation for all 10 channels
        if(newInputCount >= DETECTOR_HIT_ARRAY_SIZE){
            filter_firFilter();
            for(uint16_t j = 0; j < DETECTOR_HIT_ARRAY_SIZE; j++){
                filter_iirFilter(j);
                computedPowers[j] = filter_computePower(j,false, false);
            }
            //if the lockoutTimer is not running, run the hit-detection algorithm. If you detect a hit and the frequency with maximum power is not an ignored frequency, do the following:
            hit_detect();
            newInputCount = 0;
        }
    }
    
}

//sub function used to call our hit detection algorithm
void hit_detect(){
    if(!lockoutTimer_running()) {

for (uint16_t i = 0; i < 9; i++)
{
    /* find the min element in the unsorted a[i .. aLength-1] */

    /* assume the min is the first element */
    int jMin = i;
    /* test against elements after i to find the smallest */
    for (uint16_t j = i+1; j < 10; j++)
    {
        /* if this element is less, then it is the new minimum */
        if (computedPowers[j] < computedPowers[jMin])
        {
            /* found new minimum; remember its index */
            jMin = j;
            continue;
        }
    }

    if (jMin != i) 
    {
        swap(computedPowers[i], computedPowers[jMin]); //swap isnt found
    }
}

        // double key = 0;

        // //sorting the computed powers array in ascending order by magnitude
        // for(uint8_t i = 1; i < DETECTOR_HIT_ARRAY_SIZE; i++) {
        //     key = computedPowers[i];
        //     uint8_t j = i - 1;

        //     /* Move elements of arr[0..i-1], that are
        //     greater than key, to one position ahead
        //     of their current position */
        //     while ((j >= 0) && (computedPowers[j] > key)) {
        //         computedPowers[j + 1] = computedPowers[j];
        //         j = j - 1;
        //     }
        //     computedPowers[j + 1] = key;
        // }

        threshold = fudgeFactorIndex * computedPowers[MEDIAN_INDEX_SORTED_POWERS];

        //run the hit detected algorithm
        for(uint8_t i = 0; i < DETECTOR_HIT_ARRAY_SIZE; i++){
            maxValue = threshold;
            if(computedPowers[i] >= maxValue){
                 maxValue = computedPowers[i];

                //if it is not an ignored frequency, do the following steps to accept the defeat (you've been hit)
                if(!ignoredFrequencies){
                    //increment detector_hitArray at the index of the frequency of the IIR-filter output where you detected the hit. Note that detector_hitArray is a 10-element integer array that simply holds the current number of hits, for each frequency, that have occurred to this point.
                    detector_hitArray[i] += 1;
                    //start the lockoutTimer.
                    lockoutTimer_start();
                    //start the hitLedTimer.
                    hitLedTimer_start();
                    detector_hitDetectedFlag = true;
                }
            }
        }
    }
}   

// Returns true if a hit was detected.
bool detector_hitDetected(void) {
    return detector_hitDetectedFlag;
}

// Returns the frequency number that caused the hit.
uint16_t detector_getFrequencyNumberOfLastHit(void) {
    return frequencyOfLastHit;
}

// Clear the detected hit once you have accounted for it.
void detector_clearHit(void) {
    detector_hitDetectedFlag = false;
}

// Ignore all hits. Used to provide some limited invincibility in some game
// modes. The detector will ignore all hits if the flag is true, otherwise will
// respond to hits normally.
void detector_ignoreAllHits(bool flagValue) {
    ignoreAllHits = flagValue;
}

// Get the current hit counts.
// Copy the current hit counts into the user-provided hitArray
// using a for-loop.
void detector_getHitCounts(detector_hitCount_t hitArray[]) {
    //loop through the the detector hit array abd update the passed in hit array
    for(uint8_t i = 0; i < DETECTOR_HIT_ARRAY_SIZE; i++) {
        hitArray[i] = detector_hitArray[i];
    }
}

// Allows the fudge-factor index to be set externally from the detector.
// The actual values for fudge-factors is stored in an array found in detector.c

//THIS IS WRONG, THERE WILL BE AN ARRAY OF FUDGE FACTS BUT FOR RIGHT NOW, FUDGE IT!
void detector_setFudgeFactorIndex(uint32_t factorIdx) {
    fudgeFactorIndex = factorIdx;
}

// Returns the detector invocation count.
// The count is incremented each time detector is called.
// Used for run-time statistics.
uint32_t detector_getInvocationCount(void) {
    return detectorInvocationCount;
}

/******************************************************
******************** Test Routines ********************
******************************************************/

// Students implement this as part of Milestone 3, Task 3.
// Create two sets of power values and call your hit detection algorithm
// on each set. With the same fudge factor, your hit detect algorithm
// should detect a hit on the first set and not detect a hit on the second.
void detector_runTest(void) {
    
    fudgeFactorIndex = 200;
    filter_setCurrentPowerValue(0, 5500);
    filter_setCurrentPowerValue(1, 20);
    filter_setCurrentPowerValue(2, 40);
    filter_setCurrentPowerValue(3, 10);
    filter_setCurrentPowerValue(4, 15);
    filter_setCurrentPowerValue(5, 30);
    filter_setCurrentPowerValue(6, 35);
    filter_setCurrentPowerValue(7, 15);
    filter_setCurrentPowerValue(8, 25);
    filter_setCurrentPowerValue(9, 85);
    filter_getCurrentPowerValues(computedPowers);
    for(uint8_t i = 0; i < 10; i++) {
        printf("%d: %f\n", i, computedPowers[i]);
    }
    hit_detect();
    for(uint8_t i = 0; i < 10; i++) {
        printf("%d: %f\n", i, computedPowers[i]);
    }
    bool firstTest = detector_hitDetected();
    printf("This should say true(1): %d\n", firstTest);

    filter_setCurrentPowerValue(0, 500);
    filter_setCurrentPowerValue(1, 20);
    filter_setCurrentPowerValue(2, 40);
    filter_setCurrentPowerValue(3, 10);
    filter_setCurrentPowerValue(4, 15);
    filter_setCurrentPowerValue(5, 30);
    filter_setCurrentPowerValue(6, 35);
    filter_setCurrentPowerValue(7, 15);
    filter_setCurrentPowerValue(8, 25);
    filter_setCurrentPowerValue(9, 85);
    filter_getCurrentPowerValues(computedPowers);
    hit_detect();
    bool secondTest = detector_hitDetected();
    printf("This should say false(0): %d\n", secondTest);
}